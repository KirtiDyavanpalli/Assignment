async function myFunc(){
    function getVideo(){
        console.log("Get video");
    }
    function AddIntro(){
        return console.log("Intro Added");
    }
    function Addsummary(){
        return console.log("summary Added");
    }
    getVideo();
    await AddIntro();
    Addsummary();
}
myFunc()
console.log("The await function checking...")