function GetVideo(){
    return new Promise(function(resolve){
        setTimeout(()=>{
            resolve("Got video")
        },3000);
    });
}
function AddIntro() {
    return new Promise(function(resolve){
        setTimeout(()=>{
            resolve("Add intro")
        },3000);
    });
}
function Addsummary(){
    return new Promise(function(resolve){
        setTimeout(()=>{
            resolve("Add Summary")
        },3000);
    });
}
GetVideo().then((result)=>{
    console.log(result);
});
AddIntro().then((result)=>{
    console.log(result);
});
Addsummary().then((result)=>{
    console.log(result);
});