let str = ["kirti", "virat", "shrushti", "yashu"];
for (let i = 0; i < str.length; i++) {
    let str1 = str[i];
    for (j = 0; j < str1.length; j++) {
        if (j == str1.length - 1) {
            let last = str1[j].toUpperCase();
            console.log(last)
        }
    }
}