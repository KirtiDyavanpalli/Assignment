var mainString = "CitiusTech";
let newString = "";
for (var i = mainString.length - 1; i >= 0; i--) {
    newString = newString + mainString[i];
}
console.log(newString)