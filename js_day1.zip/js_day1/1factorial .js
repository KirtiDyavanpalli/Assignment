let arr=[2,4,3,5,6]
let arp=[1,2,3,4,5]
for(let i=0; i<5; i++){
    console.log(i)
    for(let j=arr[i]; j>=1; j--){
        arp[i]=arp[i]*j
    }
}
console.log(arp)