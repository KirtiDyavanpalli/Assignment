let arr = [10, 20, 22, 30, 40, 50, 60, 70, 80, 90];
let sum = 0;
for (let i = 0; i < 10; i++) {
    if (arr[i] % 2 == 0) {
        sum = sum + arr[i];
    }
    for (let i = 0; i < 10; i++) {
        if (arr[i] % 2 == 1) {
            alert("No Even number found.")
        }
    }
}
console.log(sum)