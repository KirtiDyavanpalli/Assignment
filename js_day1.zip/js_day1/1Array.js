let arr = [10, 20, 3, 44, 6, 7, 77, 8, 9, 21];
for (let i = 0; i < 10; i++) {
    for (let j = 0; j < 10; j++) {
        if (arr[i] > arr[j]) {
            let temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;

        }
    }
}
console.log(arr)
console.log(arr[0].arr[1])