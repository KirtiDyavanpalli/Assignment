let arr = [10, 20, 30, 40, 50, 60, 70, 80, 90, 11];
for (let i = 0; i < 10; i++) {
    for (let j = 0; j < 10; j++) {
        if (arr[i] > arr[j]) {
            let temp = arr[i];
            arr[i] = arr[j];
            arr[j] = temp;

        }
    }
}
console.log(arr)
