const num = 7312140905;
const sumDigit = (num, sum = 0) => {
   if(num){
      return sumDigit(Math.floor(num / 10), sum + (num % 10));
   }
   return sum;
};
const sumRepeatedly = num => {
   while(num > 9){
      num = sumDigit(num);
   };
   return num;
};
console.log(sumRepeatedly(num));




// function countRepeatingDigits(N) {
//     var res = 0;
//     var cnt = Array(10).fill(0);
//     while (N > 0) {
//         var rem = N % 10;
//         cnt++;
//         N = Math.floor(N / 10);

//     }
//     for (var i = 0; i < 10; i++) {
//         if (cnt[i] > 1) {
//             res++;
//         }
//     }
//     return res;
// }
// var N = 7312140905;
// console.log((countRepeatingDigits(N)));