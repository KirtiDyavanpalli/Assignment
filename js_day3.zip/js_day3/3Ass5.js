document.getElementById("hack").addEventListener("mouseover",function(){
    document.getElementById("hack").style.height="800px"; 
    document.getElementById("hack").style.width="800px";    
});

document.getElementById("hack").addEventListener("mouseout",function(){
    document.getElementById("hack").style.height="200px"; 
    document.getElementById("hack").style.width="200px";    
});