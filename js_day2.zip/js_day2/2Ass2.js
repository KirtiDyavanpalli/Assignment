const sum = (a, b) => a + b;
console.log('sum is:' + sum(7, 8));