const vehicle = {
    brand: 'Rolls-Royce',
    model: 'A-class',
    vehicleId: 105,
    variant: 'A class A200 D sport edition',

    specifications:
    {
        firstGear: 'first gear of vehicle',
        secondGear: 'second gear of vehicle',
        maxspeed: 150,
        changeGear(){
            return this.firstGear+ ''+ this.secondGear;
        }
    }
}
console.log('vehicle id:' + vehicle['vehicleId']);
console.log('Brand:' + vehicle['brand']);
console.log('model:' + vehicle['model']);
console.log('variant:' + vehicle['variant']);
console.log('speed:' + vehicle.specifications.maxspeed);
console.log('change gear:' + vehicle.specifications.changeGear());
