function validateForm(){
    let x= document.forms["myForm"]["fname"].value;
    let y= document.forms["myForm"]["fpass"].value;

    if(x==''||y=='')
    x='CT';
    y='CT';

    document.forms['myForm']['fname'].value = x;
    document.forms["myForm"]["fpass"].value = y;
}