const vehicle = {
    brand: 'Rolls-Royce',
    model: 'A-class',
    vehicleId: 105,
    variant: 'A class A200 D sport edition',

    specifications:
    {
        firstGear: 'first gear of vehicle',
        secondGear: 'second gear of vehicle',
        maxspeed: 150,
        changeGear(){
            return this.firstGear+ ''+ this.secondGear;
        }
    }
}
const showVehicleDetails = vehicle =>{
console.log(showVehicleDetails.vehicle.vehicleId);
console.log(showVehicleDetails.vehicle.brand);
console.log(showVehicleDetails.vehicle.model);
console.log(showVehicleDetails.vehicle.variant);
console.log(showVehicleDetails.vehicle.specifications.maxspeed);
//console.log('change gear:' + vehicle.specifications.changeGear());
};
